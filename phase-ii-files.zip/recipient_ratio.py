"""Compare reported male and female VA disability compensation counts."""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.ticker import StrMethodFormatter
from scipy.stats import chisquare


def main():
    project_dir = Path(__file__).resolve().parent
    data_path = project_dir / "FY 2025 Disability Compensation Recipients by County"
    data = pd.read_csv(data_path, dtype={"FIPS code": str})

    # Keep county and county-equivalent rows for the 50 states and D.C.
    fips = data["FIPS code"]
    is_county = fips.str.fullmatch(r"[0-5][0-9]{4}") & ~fips.str.endswith("000")
    counties = data.loc[is_county]
    counts = counties[["Male", "Female"]].apply(
        lambda column: pd.to_numeric(column.astype("string").str.replace(",", ""))
    )
    reported = counts.dropna()
    observed = reported.sum().astype(int)
    total = int(observed.sum())
    male, female = observed
    expected = [total / 2, total / 2]
    test = chisquare(observed, f_exp=expected)

    print("FY 2025 VA disability compensation recipients")
    print("Scope: counties and county equivalents in the 50 states and D.C.")
    print(f"County rows with both counts reported: {len(reported):,} of {len(counties):,}")
    print(f"County rows excluded for missing counts: {len(counties) - len(reported):,}")
    print(f"Male: {male:,} ({male / total:.2%})")
    print(f"Female: {female:,} ({female / total:.2%})")
    print(f"Total with a reported male or female count in included rows: {total:,}")
    print(f"Male-to-female ratio: {male / female:.2f}:1")
    print(f"Expected under an equal split: {total / 2:,.1f} in each group")
    print(f"Chi-square (df = 1): {test.statistic:,.2f}")
    # The floating-point p-value can underflow for very large statistics.
    p_value = "p < 0.001" if test.pvalue < 0.001 else f"p = {test.pvalue:.4f}"
    print(f"p-value: {p_value}")

    plot_data = pd.DataFrame(
        {"Observed": observed, "Expected (50/50)": expected}
    )
    fig, ax = plt.subplots(figsize=(8, 5), layout="constrained")
    plot_data.plot.bar(ax=ax, rot=0, color=["#205583", "#cb793c"])
    ax.set_title("FY 2025 VA disability compensation recipients")
    ax.set_xlabel("Reported group")
    ax.set_ylabel("Number of recipients")
    ax.yaxis.set_major_formatter(StrMethodFormatter("{x:,.0f}"))
    ax.set_axisbelow(True)
    ax.grid(axis="y", alpha=0.25)
    ax.set_ylim(top=observed.max() * 1.15)
    for bars in ax.containers:
        ax.bar_label(bars, padding=3, fmt=lambda count: f"{count:,.1f}".removesuffix(".0"))
    fig.savefig(project_dir / "recipient_ratio.png", dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()
